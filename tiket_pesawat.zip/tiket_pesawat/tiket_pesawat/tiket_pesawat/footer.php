  <footer class="main-footer">
    <p>&copy; <?= date("Y") ?> 🛫Tiket by agen | All rights reserved 💖</p>
  </footer>
</body>
</html>
