<?php
session_start();
include 'koneksi.php';
include 'header.php';

if (!isset($_SESSION['id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
  header("Location: index.php");
  exit;
}

$user_id = $_SESSION['id'];
$id_penerbangan = $_POST['penerbangan_id'];
$nama = $_POST['nama_penumpang'];
$identitas = $_POST['identitas'];
$paspor = $_POST['paspor'];
$kursi = $_POST['kursi'];
$jumlah = $_POST['jumlah'];

$penerbangan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM penerbangan WHERE id=$id_penerbangan"));
$harga = $penerbangan['harga'];
$total = $harga * $jumlah;

// Hitung diskon
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id=$user_id"));
$diskon = 0;

// Diskon pembelian pertama
if ($user['total_pembelian'] == 0) {
  $diskon += 0.05 * $total;
}

// Diskon pelanggan loyal
$transaksi = mysqli_query($conn, "SELECT COUNT(*) as total FROM pemesanan WHERE user_id = $user_id");
$jumlah_transaksi = mysqli_fetch_assoc($transaksi)['total'];
if ($jumlah_transaksi >= 5) {
  $diskon += 0.1 * $total;
}

$total_bayar = $total - $diskon;

// Simpan data ke session untuk ke hasil.php
$_SESSION['checkout'] = [
  'penerbangan_id' => $id_penerbangan,
  'nama' => $nama,
  'identitas' => $identitas,
  'paspor' => $paspor,
  'kursi' => $kursi,
  'jumlah' => $jumlah,
  'total' => $total_bayar,
  'diskon' => $diskon
];
?>

<div class="container">
  <h2>Konfirmasi & Pembayaran</h2>
  <p><strong>Nama:</strong> <?= $nama ?></p>
  <p><strong>Jumlah Tiket:</strong> <?= $jumlah ?></p>
  <p><strong>Total Harga:</strong> Rp <?= number_format($total, 0, ',', '.') ?></p>
  <p><strong>Total Diskon:</strong> Rp <?= number_format($diskon, 0, ',', '.') ?></p>
  <p><strong>Total Bayar:</strong> Rp <?= number_format($total_bayar, 0, ',', '.') ?></p>

  <form method="post" action="hasil.php">
    <label>Pilih Metode Pembayaran:</label>
    <select name="metode_pembayaran" required>
      <option value="">-- Pilih --</option>
      <option value="BRI">BRI 🏦</option>
      <option value="BNI">BNI 🏦</option>
      <option value="BCA">BCA 🏦</option>
      <option value="Nagari">Bank Nagari 🏦</option>
      <option value="Dana">Dana 📱</option>
    </select>

    <button type="submit">Bayar & Simpan Transaksi</button>
  </form>
</div>

<?php include 'footer.php'; ?>
