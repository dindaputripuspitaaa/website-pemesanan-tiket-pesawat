<?php
session_start();
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = $_POST['email'];
  $password = $_POST['password'];

  $cek = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
  $data = mysqli_fetch_assoc($cek);

  if ($data && password_verify($password, $data['password'])) {
    $_SESSION['id'] = $data['id'];
    $_SESSION['nama'] = $data['nama'];
    $_SESSION['level'] = $data['level'];
    $_SESSION['total_pembelian'] = $data['total_pembelian'];
    header("Location: index.php");
    exit;
  } else {
    $error = "Email atau password salah!";
  }
}
?>

<?php include 'header.php'; ?>
<div class="container">
  <h2>Login</h2>
  <?php if (isset($_GET['daftar']) && $_GET['daftar'] == 'berhasil') echo "<p style='color:green;'>Pendaftaran berhasil! Silakan login.</p>"; ?>
  <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
  <form method="post">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
  </form>
</div>
<?php include 'footer.php'; ?>
