<?php
session_start();
include 'koneksi.php';
include 'header.php';

if (!isset($_SESSION['id'])) {
  header("Location: login.php");
  exit;
}

$user_id = $_SESSION['id'];
$query = "SELECT p.*, v.maskapai, v.jenis_pesawat, v.asal, v.tujuan, v.tanggal, v.jam 
          FROM pemesanan p 
          JOIN penerbangan v ON p.penerbangan_id = v.id 
          WHERE p.user_id = $user_id 
          ORDER BY p.tanggal_pesan DESC";
$result = mysqli_query($conn, $query);
?>

<div class="container">
  <h2>Riwayat Pemesanan Tiket</h2>
  <?php if (mysqli_num_rows($result) > 0): ?>
    <table>
      <tr>
        <th>Tanggal</th>
        <th>Rute</th>
        <th>Maskapai</th>
        <th>Jumlah</th>
        <th>Metode</th>
        <th>Total</th>
        <th>Diskon</th>
      </tr>
      <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
          <td><?= $row['tanggal'] ?> <?= $row['jam'] ?></td>
          <td><?= $row['asal'] ?> - <?= $row['tujuan'] ?></td>
          <td><?= $row['maskapai'] ?> (<?= $row['jenis_pesawat'] ?>)</td>
          <td><?= $row['jumlah'] ?> tiket</td>
          <td><?= $row['metode_pembayaran'] ?></td>
          <td>Rp <?= number_format($row['total'], 0, ',', '.') ?></td>
          <td>Rp <?= number_format($row['diskon'], 0, ',', '.') ?></td>
        </tr>
      <?php endwhile; ?>
    </table>
  <?php else: ?>
    <p>Kamu belum pernah memesan tiket 😢</p>
  <?php endif; ?>
</div>

<?php include 'footer.php'; ?>
