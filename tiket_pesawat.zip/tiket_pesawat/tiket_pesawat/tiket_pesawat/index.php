<?php
session_start();
include 'koneksi.php';
?>
<?php include 'header.php'; ?>

<div class="container">
  <h2>Hi!
    Selamat Datang,dan Selamat Berbelanja di Tiketku💗</h2>
  <p>Pesan tiket pesawat dengan nyaman,cepat,dan banyak diskon bersama kami💺✈️</p>

  <?php if (isset($_SESSION['nama'])): ?>
    <p>Halo, <strong><?= $_SESSION['nama'] ?></strong> (<a href="logout.php">Logout</a>)</p>
    <a href="pesan.php"><button>Pesan Tiket</button></a>
    <a href="riwayat.php"><button>Riwayat Transaksi</button></a>
    <?php if ($_SESSION['level'] === 'admin'): ?>
      <a href="dashboard.php"><button>Dashboard Admin</button></a>
    <?php endif; ?>
  <?php else: ?>
    <a href="login.php"><button>Login</button></a>
    <a href="register.php"><button>Daftar</button></a>
  <?php endif; ?>
</div>

<?php include 'footer.php'; ?>
