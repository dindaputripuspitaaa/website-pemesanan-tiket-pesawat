<?php
session_start();
include 'koneksi.php';
include 'header.php';

if (!isset($_SESSION['id']) || $_SESSION['level'] !== 'admin') {
  header("Location: login.php");
  exit;
}

$penerbangan = mysqli_query($conn, "SELECT * FROM penerbangan ORDER BY tanggal DESC");
$pemesanan = mysqli_query($conn, "SELECT p.*, u.nama as nama_user, v.maskapai, v.asal, v.tujuan, v.tanggal, v.jam 
  FROM pemesanan p 
  JOIN users u ON p.user_id = u.id 
  JOIN penerbangan v ON p.penerbangan_id = v.id 
  ORDER BY p.tanggal_pesan DESC");
?>

<div class="container">
  <h2>Dashboard Admin</h2>

  <h3>Data Penerbangan</h3>
  <table>
    <tr>
      <th>Maskapai</th><th>Jenis</th><th>Rute</th><th>Tanggal</th><th>Jam</th><th>Harga</th>
    </tr>
    <?php while($v = mysqli_fetch_assoc($penerbangan)): ?>
    <tr>
      <td><?= $v['maskapai'] ?></td>
      <td><?= $v['jenis_pesawat'] ?></td>
      <td><?= $v['asal'] ?> ➜ <?= $v['tujuan'] ?></td>
      <td><?= $v['tanggal'] ?></td>
      <td><?= $v['jam'] ?></td>
      <td>Rp <?= number_format($v['harga'], 0, ',', '.') ?></td>
    </tr>
    <?php endwhile; ?>
  </table>

  <h3>Data Pemesanan Tiket</h3>
  <table>
    <tr>
      <th>Pelanggan</th><th>Rute</th><th>Maskapai</th><th>Jumlah</th><th>Total</th><th>Diskon</th><th>Metode</th>
    </tr>
    <?php while($p = mysqli_fetch_assoc($pemesanan)): ?>
    <tr>
      <td><?= $p['nama_user'] ?></td>
      <td><?= $p['asal'] ?> ➜ <?= $p['tujuan'] ?></td>
      <td><?= $p['maskapai'] ?></td>
      <td><?= $p['jumlah'] ?></td>
      <td>Rp <?= number_format($p['total'], 0, ',', '.') ?></td>
      <td>Rp <?= number_format($p['diskon'], 0, ',', '.') ?></td>
      <td><?= $p['metode_pembayaran'] ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
</div>

<?php include 'footer.php'; ?>
