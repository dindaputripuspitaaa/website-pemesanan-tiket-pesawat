<?php
session_start();
include 'koneksi.php';
include 'header.php';

if (!isset($_SESSION['id']) || !isset($_SESSION['checkout']) || !isset($_POST['metode_pembayaran'])) {
  header("Location: index.php");
  exit;
}

$user_id = $_SESSION['id'];
$data = $_SESSION['checkout'];
$metode = $_POST['metode_pembayaran'];

mysqli_query($conn, "INSERT INTO pemesanan (
  user_id, penerbangan_id, nama_penumpang, identitas, paspor, kursi, jumlah, metode_pembayaran, total, diskon
) VALUES (
  '$user_id',
  '{$data['penerbangan_id']}',
  '{$data['nama']}',
  '{$data['identitas']}',
  '{$data['paspor']}',
  '{$data['kursi']}',
  '{$data['jumlah']}',
  '$metode',
  '{$data['total']}',
  '{$data['diskon']}'
)");

// Update total pembelian user
mysqli_query($conn, "UPDATE users SET total_pembelian = total_pembelian + 1 WHERE id = $user_id");

unset($_SESSION['checkout']);
?>

<div class="container">
  <h2>Transaksi Berhasil 🎉</h2>
  <p>Terima kasih <strong><?= $_SESSION['nama'] ?></strong>, tiket kamu sudah berhasil dipesan!</p>
  <p>Lihat riwayat pembelian kamu di halaman <a href="riwayat.php">Riwayat Transaksi</a>.</p>
</div>

<?php include 'footer.php'; ?>
