CREATE DATABASE IF NOT EXISTS tiket_pesawat;
USE tiket_pesawat;

-- Tabel USERS
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255),
  level ENUM('admin','pelanggan') DEFAULT 'pelanggan',
  total_pembelian INT DEFAULT 0
);

-- Tabel PENERBANGAN
CREATE TABLE penerbangan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  maskapai VARCHAR(100),
  jenis_pesawat VARCHAR(100),
  asal VARCHAR(100),
  tujuan VARCHAR(100),
  tanggal DATE,
  jam TIME,
  harga INT,
  gambar VARCHAR(255),
  total_kursi INT DEFAULT 50
);

-- Tabel PEMESANAN
CREATE TABLE pemesanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  penerbangan_id INT,
  nama_penumpang VARCHAR(100),
  identitas VARCHAR(100),
  paspor VARCHAR(100),
  kursi VARCHAR(10),
  jumlah INT,
  metode_pembayaran VARCHAR(50),
  total INT,
  diskon FLOAT,
  tanggal_pesan TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (penerbangan_id) REFERENCES penerbangan(id)
);

-- Admin default (email: admin@mail.com | password: admin)
INSERT INTO users (nama, email, password, level) VALUES 
('Admin', 'admin@mail.com', '$2y$10$JjqW8r.T0vBhA1xXruvcz.vtqz20v5Gj7.HGFc6WHWDPPCvsmhK6e', 'admin');

-- Tambahkan beberapa maskapai contoh
INSERT INTO penerbangan (maskapai, jenis_pesawat, asal, tujuan, tanggal, jam, harga, gambar) VALUES
('garudaindonesia', 'Boeing 737', 'Padang', 'Jakarta', '2025-06-26', '09:00:00', 950000, 'garuda.jpg'),
('lionair', 'Airbus A320', 'Padang', 'Jakarta', '2025-06-26', '12:00:00', 750000, 'lion.jpg'),
('Citilink', 'ATR 72', 'Padang', 'Jakarta', '2025-06-26', '16:30:00', 680000, 'citilink.jpg'),
('batikair', 'Boeing 737-800', 'jakarta', 'Bali', '2025-06-27', '08:45:00', 820000, 'batikair.jpg'),
('airasia', 'Airbus A320neo', 'jakarta', 'bali', '2025-06-27', '11:30:00', 970000, 'airasia.jpg'),
('wingsair', 'ATR 72-600', 'jakarta', 'bali', '2025-06-27', '14:20:00', 560000, 'wingsair.jpg'),
('superjet', 'Airbus A320', 'Jakarta', 'medan', '2025-06-27', '06:10:00', 680000, 'superjet.jpg'),
('pelitaair', 'Boeing 737-900', 'jakarta', 'medan', '2025-06-27', '19:15:00', 890000, 'pelitaair.jpg'),
('sriwijaya', 'Boeing 737-500', 'jakarta', 'Medan', '2025-06-27', '21:50:00', 740000, 'sriwijaya.jpg');

