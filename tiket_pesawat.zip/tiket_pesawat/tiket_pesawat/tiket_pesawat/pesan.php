<?php
session_start();
include 'koneksi.php';
include 'header.php';

if (!isset($_SESSION['id'])) {
  header("Location: login.php");
  exit;
}

$penerbangan = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['asal'], $_POST['tujuan'], $_POST['tanggal'])) {
  $asal = strtolower(trim($_POST['asal']));
  $tujuan = strtolower(trim($_POST['tujuan']));
  $tanggal = $_POST['tanggal'];

  // Gunakan LOWER() untuk pencarian tidak sensitif huruf besar/kecil
  $query = "SELECT * FROM penerbangan 
            WHERE LOWER(asal) = '$asal' AND LOWER(tujuan) = '$tujuan' AND tanggal = '$tanggal'";
  $penerbangan = mysqli_query($conn, $query);
}
?>

<div class="container">
  <h2>Form Pemesanan Tiket</h2>
  <form method="post">
    <label>Kota Asal:</label>
    <input type="text" name="asal" placeholder="Contoh: Padang" required>

    <label>Kota Tujuan:</label>
    <input type="text" name="tujuan" placeholder="Contoh: Jakarta" required>

    <label>Tanggal Keberangkatan:</label>
    <input type="date" name="tanggal" required>

    <button type="submit">Cari Penerbangan</button>
  </form>

  <?php if ($penerbangan && mysqli_num_rows($penerbangan) > 0): ?>
    <form method="post" action="bayar.php">
      <h3>Penerbangan Tersedia:</h3>
      <?php while($row = mysqli_fetch_assoc($penerbangan)): ?>
        <div class="flight-card">
          <input type="radio" name="penerbangan_id" value="<?= $row['id'] ?>" required>
          <img src="img/<?= $row['gambar'] ?>" alt="<?= $row['maskapai'] ?>" style="width:100px;"><br>
          <strong><?= $row['maskapai'] ?> (<?= $row['jenis_pesawat'] ?>)</strong><br>
          <?= $row['asal'] ?> ➜ <?= $row['tujuan'] ?><br>
          Tanggal: <?= $row['tanggal'] ?> | Jam: <?= $row['jam'] ?><br>
          Harga: Rp <?= number_format($row['harga'], 0, ',', '.') ?>
        </div>
      <?php endwhile; ?>

      <h3>Data Penumpang</h3>
      <input type="text" name="nama_penumpang" placeholder="Nama Penumpang" required>
      <input type="text" name="identitas" placeholder="Nomor Identitas" required>
      <input type="text" name="paspor" placeholder="Paspor (jika ke luar negeri)">
      <input type="text" name="kursi" placeholder="Nomor Kursi" required>
      <input type="number" name="jumlah" placeholder="Jumlah Tiket" required>

      <button type="submit">Lanjut ke Pembayaran</button>
    </form>
  <?php elseif ($penerbangan): ?>
    <p style="color:red;"><strong>Maaf, tidak ada penerbangan ditemukan pada tanggal tersebut.</strong></p>
  <?php endif; ?>
</div>

<?php include 'footer.php'; ?>

